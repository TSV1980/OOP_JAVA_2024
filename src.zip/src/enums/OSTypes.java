package enums;

public enum OSTypes {
    Windows,
    Linux,
    AstraLinux,
    IOS,
    NoOS
}

