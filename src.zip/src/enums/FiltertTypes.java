package enums;

public enum FiltertTypes {
    OZU,
    HDDSize,
    OSver,
    Color
}
